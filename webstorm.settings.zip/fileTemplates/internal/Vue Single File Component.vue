<template>
#[[$END$]]#
</template>

<script>
export default {
name: '${COMPONENT_NAME}',
data(){
 return{}
},
methods:{
}
}
</script>

<style scoped>

</style>
